import UIKit
import Foundation

enum Event {
    case stepExecuted
    case angleChanged
    case stabilizationFinished
}

protocol Mediator {
    func notify(sender: Component, event: Event)
}

protocol Component {
    var controller: Mediator? {get set}
}

class AngleSensor: Component {
    var controller: Mediator?
    var value: Double = 0 {
        didSet {
            controller?.notify(sender: self, event: .angleChanged)
        }
    }
}

class BodyStabilizer: Component {
    var controller: Mediator?
    
    func stabilide() {
        print("Стабилизируем робота\n")
        controller?.notify(sender: self, event: .stabilizationFinished)
    }
}

class MovementRegulator: Component {
    var controller: Mediator?
    var nextMovesIsCancelled = false
    
    func executeStep() {
        guard !nextMovesIsCancelled else {
            return
        }
        controller?.notify(sender: self, event: .stepExecuted)
    }
}

class SystemLogger: Component {
    var controller: Mediator?
    
    func log(pitch: Double) {
        print("Угол наклона \(pitch) градусов")
    }
}

class CentralController: Mediator {
    
    var pitchAngleSensor: AngleSensor
    var rotateAngleSensor: AngleSensor
    var healingAngleSensor: AngleSensor
    
    var stabilizer: BodyStabilizer
    var movementRegulator: MovementRegulator
    var logger: SystemLogger
    
    init(pitchAngleSensor: AngleSensor,
        rotateAngleSensor: AngleSensor,
        healingAngleSensor: AngleSensor,
        stabilizer: BodyStabilizer,
        movementRegulator: MovementRegulator,
        logger: SystemLogger) {
        
        self.pitchAngleSensor = pitchAngleSensor
        self.rotateAngleSensor = rotateAngleSensor
        self.healingAngleSensor = healingAngleSensor
        
        self.stabilizer = stabilizer
        self.movementRegulator = movementRegulator
        self.logger = logger
    }
    
    func notify(sender: Component, event: Event) {
        switch event {
            
        case .stepExecuted:
        pitchAngleSensor.value = Double(arc4random_uniform(10))
        
        case .angleChanged:
            let pitchValue = pitchAngleSensor.value
            logger.log(pitch: pitchValue)
            guard pitchValue>0 else {
                print("Стабилищация не требуется\n")
                return
            }
            stabilizer.stabilide()
        case.stabilizationFinished:
            break
        }
    }
    
    func goForward(step: Int) {
        var i = 1
        while i <= step && !movementRegulator.nextMovesIsCancelled {
            print("Шаг \(i) произведен")
            movementRegulator.executeStep()
            i+=1
        }
    }
}

let pitchAngleSensor = AngleSensor()
let stabilizer = BodyStabilizer()
let movementRegulator = MovementRegulator()
let logger = SystemLogger()

let controller = CentralController(pitchAngleSensor: pitchAngleSensor,
                                   rotateAngleSensor: AngleSensor(),
                                   healingAngleSensor: AngleSensor(),
                                   stabilizer: stabilizer,
                                   movementRegulator: movementRegulator,
                                   logger: logger)

pitchAngleSensor.controller = controller
stabilizer.controller = controller
movementRegulator.controller = controller
logger.controller = controller

controller.goForward(step: 3)
