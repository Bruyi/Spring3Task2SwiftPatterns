import UIKit

class WindowsBook {
    var osVersion = ""
    var name = ""
    var cpuCodeName = ""
    var ramSize = 0
    var osVersionCode = 0
    var launcer = ""
    
    func setOSVersion() {
        self.osVersion = ""
    }
    
    func setName() {
        self.name = ""
    }
    
    func setCpuCodeName() {
        self.cpuCodeName = ""
    }
    
    func setRamSize() {
        self.ramSize = 0
    }
    
    func selLaucher() {
        self.osVersion = ""
    }
}

class WindowsBookBuilder {
    let notebook = WindowsBook()
    
    func getNotebook() -> WindowsBook {
        return self.notebook
    }
}

class LowPriceBookBiulder: WindowsBookBuilder {
    
    func setOsVersion() {
        self.notebook.osVersion = "Win.10 Home"
    }
    
    func setname() {
        self.notebook.name = "Asus"
    }
    
    func setCpuCodename() {
        self.notebook.cpuCodeName = "I3-8100H"
    }
    
    func setRamSize() {
        self.notebook.ramSize = 2048
    }
    
    func setOsVersionCode() {
        self.notebook.osVersionCode = 12512
    }
    
    func setLaucher() {
        self.notebook.launcer = "Забудь о своём компьютере, теперь он просто этот!"
    }
}

class HightPriceBookBuilder: WindowsBookBuilder {
    
    func setOsVersion() {
        self.notebook.osVersion = "Win.10 Pro"
    }
    
    func setname() {
        self.notebook.name = "Razer"
    }
    
    func setCpuCodename() {
        self.notebook.cpuCodeName = "I9-9900K"
    }
    
    func setRamSize() {
        self.notebook.ramSize = 32768
    }
    
    func setOsVersionCode() {
        self.notebook.osVersionCode = 19308
    }
    
    func setLaucher() {
        self.notebook.launcer = "Запускай хоть пять клиентов WoW - я еще и в гугле параллельно дам серфить!"
    }
}

class FactorySalesMan {
    var builder = WindowsBookBuilder()
    
    func setBuilder(aBuilder: WindowsBookBuilder) {
        self.builder = aBuilder
    }
    
    func getNotebook() -> WindowsBook {
        return self.builder.getNotebook()
    }
    
    func constructBook() {
        if let builder = builder as? LowPriceBookBiulder {
            builder.setname()
            builder.setLaucher()
            builder.setOsVersion()
            builder.setOsVersionCode()
            builder.setRamSize()
            builder.setCpuCodename()
            
        } else if let builder = builder as? HightPriceBookBuilder {
            builder.setname()
            builder.setLaucher()
            builder.setOsVersion()
            builder.setOsVersionCode()
            builder.setRamSize()
            builder.setCpuCodename()
        }
    }
}

let cheapBookBuilder = LowPriceBookBiulder()
let expensiveBookBuilder = HightPriceBookBuilder()

let director = FactorySalesMan()
director.setBuilder(aBuilder: cheapBookBuilder)
director.constructBook()
let noteBook = director.getNotebook()
print("Ноутбук от \(noteBook.name), с процессором \(noteBook.cpuCodeName)")

director.setBuilder(aBuilder: expensiveBookBuilder)
director.constructBook()
let newnoteBook = director.getNotebook()
print("Новый ноутбук от \(newnoteBook.name), с процессором \(newnoteBook.cpuCodeName)")
